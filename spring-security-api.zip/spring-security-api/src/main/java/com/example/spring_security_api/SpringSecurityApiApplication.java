package com.example.spring_security_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityApiApplication.class, args);
	}

}
