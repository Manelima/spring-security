package com.example.spring_security_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
